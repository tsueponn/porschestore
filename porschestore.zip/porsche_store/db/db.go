package db

import (
	"fmt"
	"log"
	"porsche_store/models"

	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/postgres"
)

var DB *gorm.DB

func Init() {
	var err error
	dsn := "host=localhost user=porschestore dbname=porsche_store sslmode=disable password=postgres"
	DB, err = gorm.Open("postgres", dsn)
	if err != nil {
		log.Fatal("Failed to connect to database:", err)
	}
	fmt.Println("Database connection established")
	DB.AutoMigrate(&models.Car{})
	fmt.Println("Database migrated")
}

func GetDB() *gorm.DB {
	return DB
}
