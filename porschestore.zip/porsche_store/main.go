package main

import (
	"database/sql"
	"log"

	"github.com/gin-gonic/gin"
	_ "github.com/lib/pq"
)

func main() {
	// Подключение к базе данных
	connStr := "user=porschestore password=postgres dbname=porsche_store sslmode=disable"
	db, err := sql.Open("postgres", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// Создание маршрутов
	r := gin.Default()
	r.GET("/cars", func(c *gin.Context) {
		rows, err := db.Query("SELECT id, model, year, price FROM cars")
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		defer rows.Close()

		cars := []map[string]interface{}{}
		for rows.Next() {
			var id int
			var model string
			var year int
			var price float64
			if err := rows.Scan(&id, &model, &year, &price); err != nil {
				c.JSON(500, gin.H{"error": err.Error()})
				return
			}
			car := map[string]interface{}{
				"id":    id,
				"model": model,
				"year":  year,
				"price": price,
			}
			cars = append(cars, car)
		}
		c.JSON(200, cars)
	})

	r.POST("/cars", func(c *gin.Context) {
		var newCar struct {
			Model string  `json:"model"`
			Year  int     `json:"year"`
			Price float64 `json:"price"`
		}
		if err := c.BindJSON(&newCar); err != nil {
			c.JSON(400, gin.H{"error": err.Error()})
			return
		}
		_, err := db.Exec("INSERT INTO cars (model, year, price) VALUES ($1, $2, $3)", newCar.Model, newCar.Year, newCar.Price)
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		c.JSON(201, gin.H{"status": "car added"})
	})

	// Запуск сервера
	r.Run(":8080")
}
